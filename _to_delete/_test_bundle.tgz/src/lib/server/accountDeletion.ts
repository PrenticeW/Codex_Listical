import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '../../types/supabase';

const GRACE_PERIOD_DAYS = 30;

/**
 * Result type for account deletion request
 */
export interface AccountDeletionResult {
  success: boolean;
  auditLogId?: string;
  error?: string;
}

/**
 * Creates a Supabase admin client using the service role key.
 * This should only be used in server-side contexts (Edge Functions, API routes, etc.)
 *
 * IMPORTANT: Never expose the service role key to the client.
 */
function createAdminClient(): SupabaseClient<Database> {
  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl) {
    throw new Error('Missing SUPABASE_URL environment variable');
  }

  if (!supabaseServiceKey) {
    throw new Error('Missing SUPABASE_SERVICE_ROLE_KEY environment variable');
  }

  return createClient<Database>(supabaseUrl, supabaseServiceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}

/**
 * Requests account deletion for a user.
 *
 * This function:
 * 1. Sets `deletion_requested_at` to now() on the user's profile
 * 2. Creates an entry in deletion_audit_log with status 'pending' and hashed user_id
 * 3. Returns success/failure with the audit log ID
 *
 * IMPORTANT: This function uses the database function `request_account_deletion`
 * which handles the SHA-256 hashing of the user ID for the audit log.
 *
 * @param userId - The UUID of the user requesting account deletion
 * @returns AccountDeletionResult with success status and audit log ID
 */
export async function requestAccountDeletion(
  userId: string
): Promise<AccountDeletionResult> {
  if (!userId) {
    return {
      success: false,
      error: 'User ID is required',
    };
  }

  // Validate UUID format
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(userId)) {
    return {
      success: false,
      error: 'Invalid user ID format',
    };
  }

  try {
    const adminClient = createAdminClient();

    // Call the database function that handles both the profile update
    // and audit log creation with hashed user_id
    const { data, error } = await adminClient.rpc('request_account_deletion', {
      target_user_id: userId,
    });

    if (error) {
      console.error('Account deletion request failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    // The function returns the audit log ID
    const auditLogId = data as string;

    if (!auditLogId) {
      return {
        success: false,
        error: 'Failed to create deletion audit log entry',
      };
    }

    return {
      success: true,
      auditLogId,
    };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('Account deletion request error:', err);
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Completes account deletion for a user.
 *
 * This should be called after all user data has been properly cleaned up.
 * It marks the profile as deleted and updates the audit log status.
 *
 * @param userId - The UUID of the user
 * @param auditLogId - The UUID of the audit log entry created during request
 * @returns Success/failure result
 */
export async function completeAccountDeletion(
  userId: string,
  auditLogId: string
): Promise<{ success: boolean; error?: string }> {
  if (!userId || !auditLogId) {
    return {
      success: false,
      error: 'User ID and audit log ID are required',
    };
  }

  try {
    const adminClient = createAdminClient();

    const { data, error } = await adminClient.rpc('complete_account_deletion', {
      target_user_id: userId,
      audit_log_id: auditLogId,
    });

    if (error) {
      console.error('Account deletion completion failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: data === true,
      error: data === true ? undefined : 'Deletion completion returned false',
    };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('Account deletion completion error:', err);
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Marks an account deletion as failed.
 *
 * Use this when the deletion process encounters an unrecoverable error.
 *
 * @param auditLogId - The UUID of the audit log entry
 * @returns Success/failure result
 */
export async function failAccountDeletion(
  auditLogId: string
): Promise<{ success: boolean; error?: string }> {
  if (!auditLogId) {
    return {
      success: false,
      error: 'Audit log ID is required',
    };
  }

  try {
    const adminClient = createAdminClient();

    const { data, error } = await adminClient.rpc('fail_account_deletion', {
      audit_log_id: auditLogId,
    });

    if (error) {
      console.error('Failed to mark deletion as failed:', error);
      return {
        success: false,
        error: error.message,
      };
    }

    return {
      success: data === true,
      error: data === true ? undefined : 'Failed to update audit log status',
    };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('Fail account deletion error:', err);
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Permanently deletes a user from Supabase Auth.
 *
 * WARNING: This action is IRREVERSIBLE. Only call this during hard-delete operations,
 * never during soft-delete. Once deleted, the user cannot recover their account.
 *
 * This function uses the Supabase Admin API which requires the service role key.
 * It must only be executed in server-side contexts (Edge Functions, API routes, etc.)
 *
 * @param userId - The UUID of the auth user to permanently delete
 * @returns Success/failure result with optional error message
 */
export async function deleteSupabaseAuthUser(
  userId: string
): Promise<{ success: boolean; error?: string }> {
  if (!userId) {
    return {
      success: false,
      error: 'User ID is required',
    };
  }

  // Validate UUID format
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(userId)) {
    return {
      success: false,
      error: 'Invalid user ID format',
    };
  }

  try {
    const adminClient = createAdminClient();

    const { error } = await adminClient.auth.admin.deleteUser(userId);

    if (error) {
      console.error('[deleteSupabaseAuthUser] Failed to delete auth user:', {
        userId,
        error: error.message,
        code: error.status,
      });
      return {
        success: false,
        error: error.message,
      };
    }

    console.log('[deleteSupabaseAuthUser] Successfully deleted auth user:', userId);
    return {
      success: true,
    };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('[deleteSupabaseAuthUser] Unexpected error:', {
      userId,
      error: errorMessage,
    });
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * User pending deletion with their audit log info
 */
export interface UserPendingDeletion {
  id: string;
  email: string;
  deletion_requested_at: string;
  audit_log_id: string;
}

/**
 * Result of processing a batch of deletions
 */
export interface BatchDeletionResult {
  processed: number;
  succeeded: number;
  failed: number;
  errors: Array<{ userId: string; error: string }>;
}

/**
 * Fetches users who have requested deletion and are past the grace period.
 *
 * @returns Array of users pending hard deletion
 */
export async function getUsersPendingHardDeletion(): Promise<UserPendingDeletion[]> {
  try {
    const adminClient = createAdminClient();

    const gracePeriodDate = new Date();
    gracePeriodDate.setDate(gracePeriodDate.getDate() - GRACE_PERIOD_DAYS);

    // Query profiles where deletion was requested more than 30 days ago
    // and the account hasn't been hard-deleted yet
    // Note: stripe_customer_id may not exist in all schemas - we handle this gracefully
    const { data: profiles, error: profilesError } = await adminClient
      .from('profiles')
      .select('id, email, deletion_requested_at')
      .not('deletion_requested_at', 'is', null)
      .is('deleted_at', null)
      .lt('deletion_requested_at', gracePeriodDate.toISOString());

    if (profilesError) {
      console.error('[getUsersPendingHardDeletion] Failed to fetch profiles:', profilesError);
      return [];
    }

    if (!profiles || profiles.length === 0) {
      return [];
    }

    // Get corresponding audit log entries for these users
    const result: UserPendingDeletion[] = [];

    for (const profile of profiles) {
      // Find the pending audit log entry for this user using the hash function
      const { data: auditLog, error: auditError } = await adminClient
        .from('deletion_audit_log')
        .select('id')
        .eq('user_id_hash', await hashUserId(adminClient, profile.id))
        .eq('status', 'pending')
        .order('requested_at', { ascending: false })
        .limit(1)
        .single();

      if (auditError || !auditLog) {
        console.warn('[getUsersPendingHardDeletion] No audit log found for user:', profile.id);
        continue;
      }

      result.push({
        id: profile.id,
        email: profile.email,
        deletion_requested_at: profile.deletion_requested_at!,
        audit_log_id: auditLog.id,
      });
    }

    return result;
  } catch (err) {
    console.error('[getUsersPendingHardDeletion] Unexpected error:', err);
    return [];
  }
}

/**
 * Helper to hash a user ID using the database function
 */
async function hashUserId(client: SupabaseClient<Database>, userId: string): Promise<string> {
  const { data, error } = await client.rpc('hash_user_id', { user_id: userId });
  if (error) {
    throw new Error(`Failed to hash user ID: ${error.message}`);
  }
  return data as string;
}

/**
 * Explicitly purges all of a user's data via the purge_user_data database
 * function (migration 20260801000001). Covers every table with user data,
 * including task_events, chip_task_notes, site_snapshots, archived_weeks,
 * the tactics_* tables, planner_settings, deletion_rate_limits, and the
 * profiles row itself (email, name, DOB, theme).
 */
async function purgeUserData(
  client: SupabaseClient<Database>,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  const { data, error } = await client.rpc('purge_user_data', {
    target_user_id: userId,
  });

  if (error) {
    console.error('[purgeUserData] Purge failed:', error);
    return { success: false, error: error.message };
  }

  console.log('[purgeUserData] Purged tables:', data);
  return { success: true };
}

/**
 * Verifies that zero rows of user data remain anywhere in the public schema.
 * Uses count_remaining_user_data, which dynamically discovers every table
 * with a user_id column at call time — so tables added in the future are
 * automatically covered and a deletion is never marked 'completed' while
 * any user data survives.
 */
async function verifyUserDataPurged(
  client: SupabaseClient<Database>,
  userId: string
): Promise<{ clean: boolean; leftovers?: unknown; error?: string }> {
  const { data, error } = await client.rpc('count_remaining_user_data', {
    target_user_id: userId,
  });

  if (error) {
    console.error('[verifyUserDataPurged] Verification query failed:', error);
    return { clean: false, error: error.message };
  }

  const leftovers = (data as Array<{ table_name: string; remaining_rows: number }>) || [];
  if (leftovers.length > 0) {
    console.error('[verifyUserDataPurged] User data remains after purge:', leftovers);
    return { clean: false, leftovers };
  }

  return { clean: true };
}

/**
 * Performs hard deletion of a single user's data.
 *
 * This function:
 * 1. Explicitly purges all user data from every table (purge_user_data)
 * 2. Deletes the Supabase auth user (FK cascades act as a second layer)
 * 3. Verifies zero user rows remain anywhere (count_remaining_user_data)
 * 4. Marks the audit log entry 'completed' only if verification passes
 *
 * @param user - The user to hard delete
 * @returns Success/failure result
 */
export async function hardDeleteUser(
  user: UserPendingDeletion
): Promise<{ success: boolean; error?: string }> {
  console.log('[hardDeleteUser] Starting hard deletion for user:', user.id);

  try {
    const adminClient = createAdminClient();

    // Step 1: Explicitly delete user data from every table.
    // We do NOT rely on ON DELETE CASCADE alone — a future table missing its
    // FK would otherwise silently retain data.
    const purgeResult = await purgeUserData(adminClient, user.id);
    if (!purgeResult.success) {
      throw new Error(`Data purge failed: ${purgeResult.error}`);
    }

    // Step 2: Delete Supabase auth user (removes credentials and identity;
    // any FK cascades that still fire are a harmless second layer)
    const authResult = await deleteSupabaseAuthUser(user.id);
    if (!authResult.success) {
      throw new Error(`Auth deletion failed: ${authResult.error}`);
    }

    // Step 3: Verify erasure is actually complete before recording success.
    const verifyResult = await verifyUserDataPurged(adminClient, user.id);
    if (!verifyResult.clean) {
      throw new Error(
        verifyResult.error
          ? `Purge verification failed: ${verifyResult.error}`
          : `Purge incomplete, data remains in: ${JSON.stringify(verifyResult.leftovers)}`
      );
    }

    // Step 4: Complete the deletion (updates audit log; the profile row is
    // already hard-deleted by the purge, so its UPDATE is a no-op)
    const completeResult = await completeAccountDeletion(user.id, user.audit_log_id);
    if (!completeResult.success) {
      throw new Error(`Failed to complete deletion: ${completeResult.error}`);
    }

    console.log('[hardDeleteUser] Successfully completed hard deletion for user:', user.id);
    return { success: true };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('[hardDeleteUser] Failed to hard delete user:', {
      userId: user.id,
      error: errorMessage,
    });

    // Mark the deletion as failed in the audit log
    await failAccountDeletion(user.audit_log_id);

    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Processes all users pending hard deletion.
 *
 * This is the main function called by the cron job. It:
 * 1. Fetches all users past the grace period
 * 2. Processes each deletion independently (one failure doesn't stop others)
 * 3. Returns a summary of the batch results
 *
 * @returns Batch deletion result with success/failure counts
 */
export async function processScheduledDeletions(): Promise<BatchDeletionResult> {
  console.log('[processScheduledDeletions] Starting scheduled deletion job');

  const result: BatchDeletionResult = {
    processed: 0,
    succeeded: 0,
    failed: 0,
    errors: [],
  };

  try {
    const usersPendingDeletion = await getUsersPendingHardDeletion();

    console.log(`[processScheduledDeletions] Found ${usersPendingDeletion.length} users pending deletion`);

    if (usersPendingDeletion.length === 0) {
      return result;
    }

    for (const user of usersPendingDeletion) {
      result.processed++;

      const deletionResult = await hardDeleteUser(user);

      if (deletionResult.success) {
        result.succeeded++;
      } else {
        result.failed++;
        result.errors.push({
          userId: user.id,
          error: deletionResult.error || 'Unknown error',
        });
      }
    }

    // Log summary
    console.log('[processScheduledDeletions] Batch complete:', {
      processed: result.processed,
      succeeded: result.succeeded,
      failed: result.failed,
    });

    // Alert if there were failures
    if (result.failed > 0) {
      console.error('[processScheduledDeletions] ALERT: Some deletions failed:', result.errors);
    }

    return result;
  } catch (err) {
    console.error('[processScheduledDeletions] Critical error in batch processing:', err);
    throw err;
  }
}

/**
 * Result type for admin-triggered deletion
 */
export interface AdminDeletionResult {
  success: boolean;
  userId?: string;
  email?: string;
  error?: string;
  skippedGracePeriod: boolean;
}

/**
 * Admin-only function to manually trigger hard deletion for a specific user.
 *
 * USE CASES:
 * - User requests immediate deletion (support request)
 * - Testing the deletion flow
 * - Cleanup of stuck deletions
 *
 * IMPORTANT: This function is NOT exposed as a public API.
 * Only call from server-side admin contexts (scripts, internal tools, etc.)
 *
 * @param identifier - User ID (UUID) or email address
 * @param options.skipGracePeriod - If true, deletes immediately even if grace period hasn't passed.
 *                                   Default: false (requires deletion_requested_at to be set)
 * @param options.createAuditIfMissing - If true, creates an audit log entry if one doesn't exist.
 *                                        Default: true
 * @returns AdminDeletionResult with success status and user info
 */
export async function adminTriggerHardDeletion(
  identifier: string,
  options: {
    skipGracePeriod?: boolean;
    createAuditIfMissing?: boolean;
  } = {}
): Promise<AdminDeletionResult> {
  const { skipGracePeriod = false, createAuditIfMissing = true } = options;

  console.log('[adminTriggerHardDeletion] Starting admin-triggered deletion:', {
    identifier: identifier.includes('@') ? identifier : '[UUID]',
    skipGracePeriod,
    createAuditIfMissing,
  });

  if (!identifier) {
    return {
      success: false,
      error: 'User ID or email is required',
      skippedGracePeriod: false,
    };
  }

  try {
    const adminClient = createAdminClient();

    // Determine if identifier is UUID or email
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const isUuid = uuidRegex.test(identifier);

    // Look up the user profile
    let query = adminClient
      .from('profiles')
      .select('id, email, deletion_requested_at')
      .is('deleted_at', null);

    if (isUuid) {
      query = query.eq('id', identifier);
    } else {
      query = query.eq('email', identifier.toLowerCase());
    }

    const { data: profile, error: profileError } = await query.single();

    if (profileError || !profile) {
      return {
        success: false,
        error: `User not found: ${profileError?.message || 'No matching profile'}`,
        skippedGracePeriod: false,
      };
    }

    // Check if deletion was requested (unless skipping grace period)
    if (!skipGracePeriod && !profile.deletion_requested_at) {
      return {
        success: false,
        userId: profile.id,
        email: profile.email,
        error: 'User has not requested deletion. Use skipGracePeriod: true to force deletion.',
        skippedGracePeriod: false,
      };
    }

    // Find or create audit log entry
    let auditLogId: string;

    const userIdHash = await hashUserId(adminClient, profile.id);
    const { data: existingAudit } = await adminClient
      .from('deletion_audit_log')
      .select('id')
      .eq('user_id_hash', userIdHash)
      .eq('status', 'pending')
      .order('requested_at', { ascending: false })
      .limit(1)
      .single();

    if (existingAudit) {
      auditLogId = existingAudit.id;
    } else if (createAuditIfMissing) {
      // Create a new deletion request (this also sets deletion_requested_at if not set)
      const requestResult = await requestAccountDeletion(profile.id);
      if (!requestResult.success || !requestResult.auditLogId) {
        return {
          success: false,
          userId: profile.id,
          email: profile.email,
          error: `Failed to create audit log: ${requestResult.error}`,
          skippedGracePeriod: skipGracePeriod,
        };
      }
      auditLogId = requestResult.auditLogId;
    } else {
      return {
        success: false,
        userId: profile.id,
        email: profile.email,
        error: 'No pending audit log found and createAuditIfMissing is false',
        skippedGracePeriod: false,
      };
    }

    // Perform the hard deletion
    const userPendingDeletion: UserPendingDeletion = {
      id: profile.id,
      email: profile.email,
      deletion_requested_at: profile.deletion_requested_at || new Date().toISOString(),
      audit_log_id: auditLogId,
    };

    const deletionResult = await hardDeleteUser(userPendingDeletion);

    if (!deletionResult.success) {
      return {
        success: false,
        userId: profile.id,
        email: profile.email,
        error: deletionResult.error,
        skippedGracePeriod: skipGracePeriod,
      };
    }

    console.log('[adminTriggerHardDeletion] Successfully deleted user:', {
      userId: profile.id,
      skipGracePeriod,
    });

    return {
      success: true,
      userId: profile.id,
      email: profile.email,
      skippedGracePeriod: skipGracePeriod,
    };
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('[adminTriggerHardDeletion] Unexpected error:', err);
    return {
      success: false,
      error: errorMessage,
      skippedGracePeriod: skipGracePeriod,
    };
  }
}
