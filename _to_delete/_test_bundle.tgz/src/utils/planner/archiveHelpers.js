/**
 * Archive Helper Utilities
 * Pure functions for archive operations - no side effects, no localStorage calls
 */

import {
  ARCHIVE_ROW_TYPES,
  ARCHIVE_WEEK_ID_PREFIX,
  ARCHIVED_ROW_ID_PREFIX,
  ARCHIVE_HEADER_ID,
} from '../../constants/planner/rowTypes';
import { createEmptyDayColumns } from './dayColumnHelpers';

/**
 * Generate a unique ID for archive-related rows
 * @param {string} prefix - ID prefix
 * @returns {string} Unique ID
 */
const generateUniqueId = (prefix) => {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 9);
  return `${prefix}${timestamp}-${random}`;
};

/**
 * Calculate week range string from dates array
 * @param {Date[]} dates - Array of dates
 * @returns {string} Week range (e.g., "Dec 29 - Jan 4")
 */
export const calculateWeekRange = (dates) => {
  if (!dates || dates.length === 0) return '';

  const firstDate = dates[0];
  const lastDate = dates[Math.min(6, dates.length - 1)]; // First 7 days or less

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return `${formatDate(firstDate)} - ${formatDate(lastDate)}`;
};

/**
 * Calculate week number from start date
 * @param {string} startDate - Start date in YYYY-MM-DD format (currently displayed first day)
 * @param {Date} currentDate - Current date (unused, kept for compatibility)
 * @param {number} displayedWeekNumber - The week number shown in the week row (from day columns)
 * @param {number} yearNumber - The current year number (defaults to 1)
 * @returns {object} { year, week } - Year and week number
 */
export const calculateWeekNumber = (startDate, currentDate, displayedWeekNumber = 1, yearNumber = 1) => {
  // Use the provided year number
  const year = yearNumber;

  // Use the displayed week number from the timeline
  const week = displayedWeekNumber;

  return { year, week };
};

/**
 * Create an archive week row
 * @param {object} options - Archive week options
 * @param {string} options.weekRange - Week range string
 * @param {object} options.weekNumber - { year, week } object
 * @param {object} options.dailyMinValues - Daily min values object
 * @param {object} options.dailyMaxValues - Daily max values object
 * @param {number} options.totalDays - Total number of days
 * @returns {object} Archive week row object
 */
export const createArchiveWeekRow = ({
  weekRange,
  weekNumber,
  dailyMinValues = {},
  dailyMaxValues = {},
  totalDays = 84,
  startDayIndex = 0,
}) => {
  const archiveWeekId = generateUniqueId(ARCHIVE_WEEK_ID_PREFIX);

  // Calculate min and max from the 7 days belonging to the week being archived.
  // startDayIndex is the first visible day (pole-position day 0 of that week),
  // so we read dailyMinValues[startDayIndex .. startDayIndex+6].
  let weeklyMin = 0;
  let weeklyMax = 0;

  for (let i = startDayIndex; i < Math.min(startDayIndex + 7, totalDays); i++) {
    const minValue = parseFloat(dailyMinValues[i]) || 0;
    const maxValue = parseFloat(dailyMaxValues[i]) || 0;
    weeklyMin += minValue;
    weeklyMax += maxValue;
  }

  return {
    id: archiveWeekId,
    _rowType: ARCHIVE_ROW_TYPES.ARCHIVE_WEEK,
    archiveLabel: weekRange,
    archiveWeekLabel: `Year ${weekNumber.year}, Week ${weekNumber.week}`,
    archiveWeeklyMin: weeklyMin.toFixed(2),
    archiveWeeklyMax: weeklyMax.toFixed(2),
    archiveTotalHours: '0.00', // Will be calculated from archived tasks
    groupId: archiveWeekId,
    isGroupHeader: true,
    rowNum: '',
    checkbox: '',
    project: '',
    subproject: '',
    status: '',
    task: '',
    recurring: '',
    estimate: '',
    timeValue: '',
    ...createEmptyDayColumns(totalDays),
  };
};

/**
 * Create archived project structure (header + general + unscheduled + subproject sections)
 * @param {object[]} projectRows - Array of project rows (projectHeader, projectGeneral, projectUnscheduled)
 * @param {object[]} subprojectRows - Array of subproject section rows (subprojectGeneral, subprojectUnscheduled)
 * @param {string} archiveWeekId - Archive week ID for grouping
 * @param {number} totalDays - Total number of days
 * @param {Map} projectWeeklyQuotas - Map of projectId → weeklyHours (snapshot from sent metrics)
 * @param {Map} projectIdByNickname - Map of projectNickname → projectId
 * @param {Map} projectAreaById - Map of projectId → area ('personal' | 'social' | 'growth' | 'duties' | null), from staging
 * @returns {object[]} Array of archived project rows (including subproject sections)
 */
export const createArchivedProjectStructure = (projectRows, subprojectRows, archiveWeekId, totalDays = 84, projectWeeklyQuotas = new Map(), projectIdByNickname = new Map(), projectAreaById = new Map()) => {
  const archivedRows = [];

  // Group rows by project
  const projectGroups = {};

  projectRows.forEach(row => {
    const projectKey = row.projectNickname || row.id;
    if (!projectGroups[projectKey]) {
      projectGroups[projectKey] = [];
    }
    projectGroups[projectKey].push(row);
  });

  // Create archived versions
  Object.entries(projectGroups).forEach(([projectKey, rows]) => {
    const headerRow = rows.find(r => r._rowType === 'projectHeader');
    const generalRow = rows.find(r => r._rowType === 'projectGeneral');
    const unscheduledRow = rows.find(r => r._rowType === 'projectUnscheduled');

    if (!headerRow) return;

    const groupId = generateUniqueId(`${ARCHIVED_ROW_ID_PREFIX}${projectKey}-group-`);

    // Snapshot the weekly quota for this project at archive time so it
    // stays frozen even after future "Send to System" presses.
    const projectId = projectIdByNickname.get(headerRow.projectNickname);
    const archivedWeeklyQuota = projectId != null
      ? (projectWeeklyQuotas.get(projectId) ?? 0)
      : 0;

    // Snapshot the staging area assignment the same way — frozen at archive
    // time so later area changes on the Goal page don't rewrite history.
    // null = unassigned (and old archives without this field read as null).
    const archivedArea = projectId != null
      ? (projectAreaById.get(projectId) ?? null)
      : null;

    // Create archived project header
    const archivedHeader = {
      ...headerRow,
      id: generateUniqueId(`${ARCHIVED_ROW_ID_PREFIX}${headerRow.id}-`),
      _rowType: ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_HEADER,
      parentGroupId: archiveWeekId,
      groupId: groupId,
      isGroupHeader: false,
      archivedWeeklyQuota,
      archivedArea,
      // Stamp the stable project id so the archived header keeps resolving
      // staging metadata (colour) even after nickname renames.
      projectId: projectId ?? headerRow.projectId ?? null,
    };
    archivedRows.push(archivedHeader);

    // Create archived general section
    if (generalRow) {
      const archivedGeneral = {
        ...generalRow,
        id: generateUniqueId(`${ARCHIVED_ROW_ID_PREFIX}${generalRow.id}-`),
        _rowType: ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_GENERAL,
        parentGroupId: groupId, // Point to the archived project header's groupId
        isGroupHeader: false,
      };
      archivedRows.push(archivedGeneral);
    }

    // Create archived unscheduled section
    if (unscheduledRow) {
      const archivedUnscheduled = {
        ...unscheduledRow,
        id: generateUniqueId(`${ARCHIVED_ROW_ID_PREFIX}${unscheduledRow.id}-`),
        _rowType: ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_UNSCHEDULED,
        parentGroupId: groupId, // Point to the archived project header's groupId
        isGroupHeader: false,
      };
      archivedRows.push(archivedUnscheduled);
    }

    // Archive custom subproject section rows that belong to this project
    const projectSubprojectRows = subprojectRows.filter(row => {
      // Match by parentGroupId - subproject rows have parentGroupId pointing to their project's groupId
      return row.parentGroupId === headerRow.groupId;
    });

    projectSubprojectRows.forEach(subRow => {
      const archivedSubRow = {
        ...subRow,
        id: generateUniqueId(`${ARCHIVED_ROW_ID_PREFIX}${subRow.id}-`),
        // Keep the original _rowType (subprojectGeneral or subprojectUnscheduled)
        parentGroupId: groupId, // Point to the archived project header's groupId
        isGroupHeader: false,
      };
      archivedRows.push(archivedSubRow);
    });
  });

  return archivedRows;
};

/**
 * Collect tasks matching filter criteria
 * @param {object[]} data - Data array
 * @param {function} filterFn - Filter function (task => boolean)
 * @returns {object[]} Array of matching tasks (including subproject section rows)
 */
export const collectTasksForArchive = (data, filterFn) => {
  return data.filter(row => {
    // Never re-collect rows that already live inside an archive week —
    // without this, each new archive drains the previous archives' Done
    // and Abandoned tasks into itself.
    if (row._isArchivedTask) return false;

    // Exclude special header rows, but INCLUDE subproject section rows
    if (row._isMonthRow || row._isWeekRow || row._isDayRow ||
        row._isDayOfWeekRow || row._isDailyMinRow || row._isDailyMaxRow ||
        row._isDailyTotalRow || row._isFilterRow || row._isInboxRow || row._isArchiveRow) {
      return false;
    }

    // Exclude project structure rows (but keep subproject section rows)
    if (row._rowType === 'projectHeader' ||
        row._rowType === 'projectGeneral' ||
        row._rowType === 'projectUnscheduled' ||
        row._rowType === 'subprojectHeader' ||
        row._rowType === 'archiveHeader' ||
        row._rowType === 'archiveRow' ||
        row._rowType === 'archivedProjectHeader' ||
        row._rowType === 'archivedProjectGeneral' ||
        row._rowType === 'archivedProjectUnscheduled') {
      return false;
    }

    // Include subproject section rows (subprojectGeneral, subprojectUnscheduled) and regular task rows
    return filterFn(row);
  });
};

/**
 * Create a deep copy snapshot of a recurring task
 * @param {object} task - Task object
 * @returns {object} Deep copy of task with new ID
 */
export const snapshotRecurringTask = (task) => {
  return {
    ...task,
    id: generateUniqueId(`${ARCHIVED_ROW_ID_PREFIX}${task.id}-snapshot-`),
    // Deep copy day entries if they exist
    ...(task.dayEntries ? { dayEntries: [...task.dayEntries] } : {}),
  };
};

/**
 * Insert archive week row after existing archive rows (or after archive header)
 * @param {object[]} data - Data array
 * @param {object} archiveWeekRow - Archive week row to insert
 * @returns {object[]} New data array with archive week row inserted
 */
export const insertArchiveRow = (data, archiveWeekRow) => {
  const newData = [...data];

  // Find archive header
  const archiveHeaderIndex = newData.findIndex(row => row._rowType === ARCHIVE_ROW_TYPES.ARCHIVE_HEADER);

  if (archiveHeaderIndex === -1) {
    // Archive header doesn't exist, insert at end
    newData.push(archiveWeekRow);
    return newData;
  }

  // Find the last archive row (after archive header)
  let insertIndex = archiveHeaderIndex + 1;
  for (let i = archiveHeaderIndex + 1; i < newData.length; i++) {
    if (newData[i]._rowType === ARCHIVE_ROW_TYPES.ARCHIVE_WEEK ||
        newData[i]._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_HEADER ||
        newData[i]._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_GENERAL ||
        newData[i]._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_UNSCHEDULED ||
        newData[i].parentGroupId) {
      insertIndex = i + 1;
    } else {
      break;
    }
  }

  newData.splice(insertIndex, 0, archiveWeekRow);
  return newData;
};

/**
 * Insert archived projects after archive week row
 * @param {object[]} data - Data array
 * @param {object[]} archivedProjects - Archived project rows
 * @param {string} archiveWeekId - Archive week ID
 * @returns {object[]} New data array with archived projects inserted
 */
export const insertArchivedProjects = (data, archivedProjects, archiveWeekId) => {
  const newData = [...data];

  // Find the archive week row
  const archiveWeekIndex = newData.findIndex(row => row.id === archiveWeekId);

  if (archiveWeekIndex === -1) {
    return newData;
  }

  // Insert archived projects right after archive week row
  newData.splice(archiveWeekIndex + 1, 0, ...archivedProjects);

  return newData;
};

/**
 * Move tasks to archive sections
 * @param {object[]} data - Data array
 * @param {object[]} tasksToArchive - Tasks to archive
 * @param {string} archiveWeekId - Archive week ID
 * @returns {object[]} New data array with tasks moved to archive
 */
export const moveTasksToArchive = (data, tasksToArchive, archiveWeekId) => {
  let newData = [...data];

  // Build a lookup from groupId → projectNickname using project headers in data
  // This lets us resolve a task's project even when task.project is empty,
  // by walking from the task's parentGroupId up to its owning project header.
  const groupIdToProjectNickname = {};
  const groupIdToParentGroupId = {};
  newData.forEach(row => {
    if (row._rowType === 'projectHeader' && row.groupId && row.projectNickname) {
      groupIdToProjectNickname[row.groupId] = row.projectNickname;
    }
    // Track subproject/section parentGroupId so we can walk up to the project
    if (row.groupId && row.parentGroupId) {
      groupIdToParentGroupId[row.groupId] = row.parentGroupId;
    }
  });

  // Resolve a task's project nickname from its parentGroupId chain
  const resolveProjectKey = (task) => {
    // Prefer explicit fields first
    if (task.projectNickname) return task.projectNickname;
    if (task.project) return task.project;

    // Walk up the parentGroupId chain to find the owning project header
    let groupId = task.parentGroupId;
    const visited = new Set();
    while (groupId && !visited.has(groupId)) {
      visited.add(groupId);
      if (groupIdToProjectNickname[groupId]) {
        return groupIdToProjectNickname[groupId];
      }
      groupId = groupIdToParentGroupId[groupId];
    }

    return '-';
  };

  // Remove tasks from their current positions
  tasksToArchive.forEach(task => {
    const index = newData.findIndex(row => row.id === task.id);
    if (index !== -1) {
      newData.splice(index, 1);
    }
  });

  // Group tasks by project and status target (general vs unscheduled)
  const tasksByProject = {};

  tasksToArchive.forEach(task => {
    const projectKey = resolveProjectKey(task);
    const targetSection = task.status === 'Done' ? 'general' : 'unscheduled';

    if (!tasksByProject[projectKey]) {
      tasksByProject[projectKey] = { general: [], unscheduled: [] };
    }

    tasksByProject[projectKey][targetSection].push({
      ...task,
      parentGroupId: archiveWeekId,
    });
  });

  // Insert tasks into their archived sections
  Object.entries(tasksByProject).forEach(([projectKey, sections]) => {
    // Find the archived project header to get its groupId
    const archivedProjectHeader = newData.find(row =>
      row._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_HEADER &&
      row.projectNickname === projectKey &&
      row.parentGroupId === archiveWeekId
    );

    if (!archivedProjectHeader) return;

    const archivedProjectGroupId = archivedProjectHeader.groupId;

    // Find the archived general section for this project
    const generalSectionIndex = newData.findIndex(row =>
      row._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_GENERAL &&
      row.projectNickname === projectKey &&
      row.parentGroupId === archivedProjectGroupId
    );

    // Find the archived unscheduled section for this project
    const unscheduledSectionIndex = newData.findIndex(row =>
      row._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_UNSCHEDULED &&
      row.projectNickname === projectKey &&
      row.parentGroupId === archivedProjectGroupId
    );

    // Insert general tasks with correct parentGroupId
    if (generalSectionIndex !== -1 && sections.general.length > 0) {
      const tasksWithCorrectParent = sections.general.map(task => ({
        ...task,
        parentGroupId: archivedProjectGroupId, // Point to archived project, not archive week
        _isArchivedTask: true,
      }));
      newData.splice(generalSectionIndex + 1, 0, ...tasksWithCorrectParent);
    }

    // Insert unscheduled tasks (need to recalculate index after general insertion)
    if (unscheduledSectionIndex !== -1 && sections.unscheduled.length > 0) {
      const newUnscheduledIndex = newData.findIndex(row =>
        row._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_UNSCHEDULED &&
        row.projectNickname === projectKey &&
        row.parentGroupId === archivedProjectGroupId
      );
      if (newUnscheduledIndex !== -1) {
        const tasksWithCorrectParent = sections.unscheduled.map(task => ({
          ...task,
          parentGroupId: archivedProjectGroupId, // Point to archived project, not archive week
          _isArchivedTask: true,
        }));
        newData.splice(newUnscheduledIndex + 1, 0, ...tasksWithCorrectParent);
      }
    }
  });

  return newData;
};

/**
 * Insert recurring task snapshots into archive
 * @param {object[]} data - Data array
 * @param {object[]} snapshots - Recurring task snapshots
 * @param {string} archiveWeekId - Archive week ID
 * @returns {object[]} New data array with snapshots inserted
 */
export const insertRecurringSnapshots = (data, snapshots, archiveWeekId) => {
  // Add parentGroupId to snapshots
  const snapshotsWithGroup = snapshots.map(snapshot => ({
    ...snapshot,
    parentGroupId: archiveWeekId,
  }));

  return moveTasksToArchive(data, snapshotsWithGroup, archiveWeekId);
};

/**
 * Reset recurring tasks (clear day entries, set status to "Not Scheduled")
 * @param {object[]} data - Data array
 * @param {number} totalDays - Total number of days
 * @returns {object[]} New data array with recurring tasks reset
 */
export const resetRecurringTasks = (data, totalDays = 84) => {
  return data.map(row => {
    // Archived snapshots are a frozen record — never reset them, or a later
    // archive wipes the Done statuses recorded in earlier archive weeks.
    if (row._isArchivedTask || row.archiveWeekLabel) return row;

    // Only reset recurring tasks with Done or Abandoned status
    if (row.recurring && ['Done', 'Abandoned'].includes(row.status)) {
      const updates = {
        status: 'Not Scheduled',
        checkbox: '',
      };

      // Clear all day entries
      for (let i = 0; i < totalDays; i++) {
        updates[`day-${i}`] = '';
      }

      return { ...row, ...updates };
    }

    return row;
  });
};

/**
 * Resolve the archive context for rows inserted at a given position.
 *
 * When the user adds task rows while anchored inside the Archive section
 * (right-clicked or selected an archive week row, an archived project
 * header/section row, or an archived task), the new rows must be stamped as
 * archive members — otherwise the Supabase load path (which rebuilds the
 * archive block purely from the parentGroupId chain) relocates them out of
 * the section on the next realtime refresh, and they never count toward the
 * week's totals or appear in the Archive Week panel.
 *
 * Returns { parentGroupId, projectNickname, project } for the archived
 * project group the new rows should join, or null when the insert position
 * is not inside the archive section.
 *
 * @param {object[]} data - Data array
 * @param {number} insertIndex - Index the new rows will be spliced at
 * @returns {object|null} Archive context, or null outside the archive
 */
export const getArchiveInsertContext = (data, insertIndex) => {
  const anchorIdx = insertIndex - 1;
  const anchor = data[anchorIdx];
  if (!anchor) return null;

  const isWeek = (r) => r._rowType === ARCHIVE_ROW_TYPES.ARCHIVE_WEEK;
  const isHeader = (r) => r._rowType === ARCHIVE_ROW_TYPES.ARCHIVED_PROJECT_HEADER;
  const headerCtx = (header) => ({
    parentGroupId: header.groupId,
    projectNickname: header.projectNickname || header.project || '',
    project: header.projectNickname || header.project || '',
  });

  // Is the anchor row part of the archive section at all?
  const inArchive =
    isWeek(anchor) ||
    isHeader(anchor) ||
    anchor._isArchivedTask === true ||
    (typeof anchor._rowType === 'string' && anchor._rowType.startsWith('archived')) ||
    (!!anchor.parentGroupId && data.some((r) => isWeek(r) && r.id === anchor.parentGroupId)) ||
    (!!anchor.parentGroupId && data.some((r) => isHeader(r) && r.groupId === anchor.parentGroupId));
  if (!inArchive) return null;

  // Anchored on the week row itself: attach to its first archived project
  // header (rows join that group; on reload they render under it). A week
  // with no project headers falls back to the week id so the rows at least
  // stay inside the week block.
  if (isWeek(anchor)) {
    const firstHeader = data.find((r) => isHeader(r) && r.parentGroupId === anchor.id);
    if (firstHeader) return headerCtx(firstHeader);
    return { parentGroupId: anchor.id, projectNickname: '', project: '' };
  }

  // Otherwise use the nearest archived project header at or above the anchor,
  // stopping at the top of the current archive week.
  for (let i = anchorIdx; i >= 0; i--) {
    const row = data[i];
    if (isHeader(row)) return headerCtx(row);
    if (isWeek(row)) break;
  }

  // Anchor sits inside a week but above any project header (e.g. a snapshot
  // row parented directly to the week): keep the rows in the week block.
  const weekParent = data.find((r) => isWeek(r) && r.id === anchor.parentGroupId);
  if (weekParent) return { parentGroupId: weekParent.id, projectNickname: '', project: '' };

  const headerParent = data.find((r) => isHeader(r) && r.groupId === anchor.parentGroupId);
  if (headerParent) return headerCtx(headerParent);

  return null;
};
