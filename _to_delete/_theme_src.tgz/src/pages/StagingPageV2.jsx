import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useNavigate } from 'react-router-dom';
import { getContrastTextColor } from '../utils/colorUtils';
import { SquarePlus } from 'lucide-react';
import { GOAL_PANEL_ACTION_EVENT, GOAL_PANEL_STATE_EVENT, GOAL_PANEL_SELECTION_EVENT, GOAL_PANEL_ROW_SELECTION_EVENT } from '../components/GoalPanel';
import { useYear } from '../contexts/YearContext';
import { useAuth } from '../contexts/AuthContext';
import NavigationBar from '../components/planner/NavigationBar';
import { undoDraftYear } from '../utils/planner/undoDraftYear';
import { revertArchive } from '../utils/planner/revertArchive';
import { createDraftYearFromActive } from '../utils/planner/createDraftYear';
import { ArchiveYearModal } from '../components/ArchiveYearModal';
import usePageSize, { usePageScaleVar } from '../hooks/usePageSize';
import usePanelInset from '../hooks/usePanelInset';
import {
  useShortlistState,
  usePlanTableState,
  usePlanTableFocus,
  useCommandPattern,
  usePlanTableSelection,
  useStagingKeyboardHandlers,
  usePlanTableDragAndDrop,
  useRowCommands,
} from '../hooks/staging';
import TableRow from '../components/staging/TableRow';
import InlineEditableText from '../components/staging/InlineEditableText';
import {
  clonePlanTableEntries,
  cloneStagingState,
  COL,
  PLAN_TABLE_COLS,
  parseTimeValueToMinutes,
  formatMinutesToHHmm,
  calculateOutcomeTotals,
  calculateOutcomeSectionTotal,
  defineRowMetadata,
  cloneRowWithMetadata,
} from '../utils/staging/planTableHelpers';
import {
  handleCopyOperation,
  handlePasteOperation,
} from '../utils/staging/clipboardOperations';
import { loadTacticsChipsState, saveTacticsChipsState } from '../lib/tacticsStorage';
import { readTaskRows, saveTaskRows } from '../utils/planner/storage';
import { DEFAULT_PROJECT_ID } from '../constants/plannerStorageKeys';

/**
 * Helper to get section type for any row by finding the nearest header above
 */
const getSectionTypeForRow = (entries, rowIdx) => {
  if (!entries || rowIdx < 0) return '';
  if (entries[rowIdx]?.__rowType === 'header') {
    return entries[rowIdx].__sectionType || '';
  }
  for (let i = rowIdx; i >= 0; i--) {
    if (entries[i]?.__rowType === 'header') {
      return entries[i].__sectionType || '';
    }
  }
  return '';
};

/**
 * Calculate time totals for an item's plan table
 * Project total only includes Schedule section (not Actions)
 */
const calculateTimeTotals = (planEntries) => {
  let scheduleTotalMinutes = 0;
  let currentSection = '';

  for (let i = 0; i < planEntries.length; i++) {
    const row = planEntries[i];
    if (row?.__rowType === 'header') {
      // Use __sectionType metadata for reliable section detection
      currentSection = row.__sectionType || '';
    } else if (currentSection === 'Schedule') {
      if (row?.__rowType === 'response' || row?.__rowType === 'prompt') {
        const value = row[COL.TIME_VALUE] ?? '';
        const minutes = parseTimeValueToMinutes(value);
        scheduleTotalMinutes += minutes;
      }
    }
  }

  return {
    scheduleTotal: formatMinutesToHHmm(scheduleTotalMinutes),
    projectTotal: formatMinutesToHHmm(scheduleTotalMinutes),
  };
};

/**
 * StagingPage (Goals/Staging) - Refactored version
 *
 * Manages project shortlist and planning tables with unified row rendering
 */
export default function StagingPageV2() {
  const navigate = useNavigate();
  const { currentYear, draftYear, activeYear, allYears, isCurrentYearArchived, refreshMetadata, switchToYear } = useYear();

  const [isArchiveModalOpen, setIsArchiveModalOpen] = useState(false);

  const handleUndoDraft = useCallback(async () => {
    const result = await undoDraftYear();
    if (result.success) {
      refreshMetadata();
    }
  }, [refreshMetadata]);

  // Dev revert archive handler — remove before launch
  const handleRevertArchive = useCallback(async () => {
    const result = await revertArchive();
    if (result.success) {
      refreshMetadata();
    } else {
      // eslint-disable-next-line no-alert
      alert(`Could not revert archive: ${result.error}`);
    }
  }, [refreshMetadata]);

  const handlePlanNextYear = useCallback(async () => {
    if (!activeYear) return;
    const result = await createDraftYearFromActive(activeYear.yearNumber);
    if (result.success) {
      refreshMetadata();
      navigate('/staging');
    } else {
      // eslint-disable-next-line no-alert
      alert(`Could not create draft year: ${result.error}`);
    }
  }, [activeYear, refreshMetadata, navigate]);
  const { isLoading: isAuthLoading } = useAuth();

  const { sizeScale } = usePageSize('goal');
  const textSizeScale = sizeScale;
  // Publish the Goal page scale as --pz so all page content (incl. portals)
  // can size with calc(Npx * var(--pz)).
  usePageScaleVar(sizeScale);

  // Command pattern for undo/redo
  const { canUndo, canRedo, executeCommand, undo, redo } = useCommandPattern();

  // Broadcast undo/redo availability to GoalPanel whenever it changes
  useEffect(() => {
    window.dispatchEvent(new CustomEvent(GOAL_PANEL_STATE_EVENT, {
      detail: { undoAvailable: canUndo, redoAvailable: canRedo },
    }));
  }, [canUndo, canRedo]);

  // Listen for actions fired by GoalPanel (undo/redo — no shortlist dependency)
  useEffect(() => {
    const handler = (e) => {
      if (e.detail?.action === 'undo') undo();
      else if (e.detail?.action === 'redo') redo();
    };
    window.addEventListener(GOAL_PANEL_ACTION_EVENT, handler);
    return () => window.removeEventListener(GOAL_PANEL_ACTION_EVENT, handler);
  }, [undo, redo]);

  // Selected goal — drives GoalPanel Goal section
  const [selectedGoalId, setSelectedGoalId] = useState(null);

  const fireGoalSelection = useCallback((item, subprojectsOverride) => {
    if (!item) {
      window.dispatchEvent(new CustomEvent(GOAL_PANEL_SELECTION_EVENT, { detail: { goal: null } }));
      return;
    }
    // Extract subproject names from plan entries (unless caller supplies override)
    let subprojects = subprojectsOverride;
    if (!subprojects) {
      const entries = item.planTableEntries || [];
      let inSubprojects = false;
      subprojects = [];
      for (const row of entries) {
        if (row?.__rowType === 'header') {
          inSubprojects = row.__sectionType === 'Subprojects';
        } else if (inSubprojects && row?.__rowType === 'prompt') {
          // Prompt rows: name at col 1 (matches useProjectsData format)
          const name = (row[COL.LABEL] ?? '').trim();
          if (name && name !== 'Subproject') subprojects.push(name);
        }
      }
    }
    window.dispatchEvent(new CustomEvent(GOAL_PANEL_SELECTION_EVENT, {
      detail: {
        goal: {
          id: item.id,
          name: item.projectName || item.text || '',
          tagline: item.projectTagline ?? '',
          color: item.color ?? '',
          projectNickname: item.projectNickname ?? '',
          addedToPlan: !!item.addedToPlan,
          subprojects,
        },
      },
    }));
  }, []);

  // Shortlist state management
  const {
    inputValue,
    setInputValue,
    shortlist,
    archived,
    setState,
    handleAdd,
    handleRemove,
    handleArchiveWithStatus,
    togglePlanTable,
  } = useShortlistState({ currentYear, executeCommand, isCurrentYearArchived });

  // Archive project and clean up associated chips + task rows
  const handleArchiveAndCleanup = useCallback(async (id, status) => {
    handleArchiveWithStatus(id, status);

    // Remove chips for the archived project. After helper #4's Supabase port
    // these calls are async; the callback now returns a Promise but no caller
    // awaits it, which is fine — the cleanup is fire-and-forget by design.
    try {
      const chipState = await loadTacticsChipsState(currentYear);
      const projectChips = Array.isArray(chipState.projectChips) ? chipState.projectChips : [];
      const filteredChips = projectChips.filter((chip) => chip.projectId !== id);
      if (filteredChips.length !== projectChips.length) {
        const remainingIds = new Set(filteredChips.map((chip) => chip.id));
        const overrides = chipState.chipTimeOverrides && typeof chipState.chipTimeOverrides === 'object'
          ? chipState.chipTimeOverrides
          : null;
        const filteredOverrides = overrides
          ? Object.fromEntries(Object.entries(overrides).filter(([chipId]) => remainingIds.has(chipId)))
          : overrides;
        await saveTacticsChipsState(
          {
            projectChips: filteredChips,
            customProjects: chipState.customProjects,
            chipTimeOverrides: filteredOverrides,
          },
          currentYear
        );
      }
    } catch (err) {
      console.error('Failed to clean up chips on archive', err);
    }
  }, [handleArchiveWithStatus, currentYear]);

  // Plan table operations
  const {
    pendingFocusRequestRef,
    addPlanPromptRow,
    addQuestionPromptWithOutcomeRow,
    addNeedsPromptWithPlanRow,
    removePlanPromptRow,
    handlePlanTableCellChange,
    handlePlanEstimateChange,
  } = usePlanTableState({ setState, executeCommand });

  // Focus management
  usePlanTableFocus({ pendingFocusRequestRef, shortlist });

  // Cell selection for tables
  const {
    selectedCells,
    selectedRows,
    setSelectedCells,
    isCellSelected,
    isRowSelected,
    handleCellMouseDown,
    handleCellMouseEnter,
    handleMouseUp,
    selectRow,
    clearSelection,
    getSelectedCellsByItem,
  } = usePlanTableSelection();

  // Drag and drop for rows
  const {
    draggedRows,
    dropTarget,
    handleDragStart,
    handleDragOver,
    handleDrop,
    handleDragEnd,
    isRowDragged,
    isDropTarget,
  } = usePlanTableDragAndDrop({
    setState,
    selectedRows,
    executeCommand,
  });

  // Row commands (insert, delete, duplicate, etc.)
  const {
    insertRowAbove,
    insertRowBelow,
    deleteRows,
    duplicateRows,
    clearCells,
    insertRowType,
    addRowOnEnter,
    toggleItemOutcomeTotals,
    toggleItemActionTimes,
  } = useRowCommands({
    setState,
    executeCommand,
    clearSelection,
    pendingFocusRequestRef,
    setSelectedCells,
  });

  // Keep GoalPanel in sync whenever the selected goal's panel-visible fields
  // change (colour, nickname, plan status, name, tagline, toggles). Excluded:
  // planTableEntries — it changes on every cell keystroke and would cause the
  // panel to re-render while the user types. Subproject changes go through
  // fireGoalSelection directly in the action handler so they're still covered.
  const _selectedGoalSyncKey = useMemo(() => {
    if (!selectedGoalId) return null;
    const g = shortlist.find((i) => i.id === selectedGoalId);
    if (!g) return null;
    return [
      g.color, g.projectNickname, g.addedToPlan,
      g.projectName, g.projectTagline,
      g.showOutcomeTotals, g.showActionTimes,
    ].join('\x00');
  }, [shortlist, selectedGoalId]);

  useEffect(() => {
    if (!selectedGoalId || _selectedGoalSyncKey === null) return;
    const item = shortlist.find((i) => i.id === selectedGoalId);
    if (item) fireGoalSelection(item);
    // shortlist intentionally omitted: _selectedGoalSyncKey already captures
    // the fields we care about and prevents the effect from running on unrelated edits.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [_selectedGoalSyncKey, selectedGoalId, fireGoalSelection]);

  // Row/cell selection → GoalPanel Row section. Fires the first selected
  // row's context (section + row type); null when nothing is selected.
  useEffect(() => {
    const firstKey = selectedRows.size > 0
      ? selectedRows.values().next().value
      : (selectedCells.size > 0 ? selectedCells.values().next().value : null);

    const fireNull = () => window.dispatchEvent(
      new CustomEvent(GOAL_PANEL_ROW_SELECTION_EVENT, { detail: { row: null } })
    );

    if (!firstKey) { fireNull(); return; }
    const [itemIdStr, rowIdxStr] = firstKey.split('|');
    const rowIdx = parseInt(rowIdxStr, 10);
    const item = shortlist.find((i) => String(i.id) === itemIdStr);
    const entries = item?.planTableEntries || [];
    const entry = entries[rowIdx];
    if (!item || !entry) { fireNull(); return; }

    // Section type: from row metadata, else walk back to the owning header
    let sectionType = entry.__sectionType || '';
    if (!sectionType) {
      for (let i = rowIdx; i >= 0; i--) {
        if (entries[i]?.__rowType === 'header') {
          sectionType = entries[i].__sectionType || '';
          break;
        }
      }
    }

    const rowType = entry.__rowType || 'row';
    // Determine if this is the first row of its type within its section
    let sectionStart = rowIdx;
    for (let i = rowIdx - 1; i >= 0; i--) {
      if (entries[i]?.__rowType === 'header') { sectionStart = i + 1; break; }
      if (i === 0) sectionStart = 0;
    }
    const isFirstOfType = !entries.slice(sectionStart, rowIdx).some(e => e?.__rowType === rowType);

    window.dispatchEvent(new CustomEvent(GOAL_PANEL_ROW_SELECTION_EVENT, {
      detail: {
        row: {
          goalId: item.id,
          rowIdx,
          sectionType,
          rowType,
          showOutcomeTotals: item.showOutcomeTotals || false,
          showActionTimes: item.showActionTimes === true,
          isFirstOfType,
        },
      },
    }));
  }, [selectedRows, selectedCells, shortlist]);

  // Global mouseup listener for drag selection
  useEffect(() => {
    window.addEventListener('mouseup', handleMouseUp);
    return () => window.removeEventListener('mouseup', handleMouseUp);
  }, [handleMouseUp]);

  // Copy handler
  const handleCopy = useCallback(
    (e) => {
      const tsvData = handleCopyOperation({ selectedCells, shortlist });
      if (tsvData) {
        e.preventDefault();
        e.clipboardData.setData('text/plain', tsvData);
      }
    },
    [selectedCells, shortlist]
  );

  // Paste handler
  const handlePaste = useCallback(
    (e) => {
      const clipboardText = e.clipboardData.getData('text/plain');
      const command = handlePasteOperation({
        clipboardText,
        selectedCells,
        shortlist,
        setState,
      });
      if (command) {
        e.preventDefault();
        executeCommand(command);
      }
    },
    [selectedCells, shortlist, setState, executeCommand]
  );

  // Keyboard handlers for undo/redo, delete, etc.
  useStagingKeyboardHandlers({
    selectedCells,
    selectedRows,
    undo,
    redo,
    executeCommand,
    setState,
    clearSelection,
    handleCopy,
    handlePaste,
  });

  // Add to Plan handler
  const handleTogglePlanStatus = useCallback(
    (itemId, addToPlan) => {
      let capturedState = null;
      let capturedChipState = null;
      let capturedTaskRows = null;
      const command = {
        execute: () => {
          setState((prev) => {
            if (capturedState === null) {
              capturedState = cloneStagingState(prev);
            }
            return {
              ...prev,
              shortlist: prev.shortlist.map((item) =>
                item.id === itemId
                  ? {
                      ...item,
                      addedToPlan: addToPlan,
                    }
                  : item
              ),
            };
          });
          if (!addToPlan) {
            const removedItem = shortlist.find((item) => item.id === itemId);
            const projectKey = ((removedItem?.projectNickname || '').trim()) || ((removedItem?.projectName || '').trim());
            if (projectKey) {
              // Task-row cleanup is now async (Supabase). The command
              // pattern's execute is synchronous and not awaited, so wrap
              // the read + filter + save in an async IIFE. capturedTaskRows
              // is set inside the IIFE so undo() restores the pre-archive
              // state; same trade-off as the chip cleanup just below.
              (async () => {
                try {
                  const taskRows = await readTaskRows(DEFAULT_PROJECT_ID, currentYear);
                  if (capturedTaskRows === null) {
                    capturedTaskRows = taskRows;
                  }
                  const projectGroupId = `project-${projectKey}`;
                  const groupIdsToRemove = new Set([projectGroupId]);
                  taskRows.forEach((row) => {
                    if (
                      row?._rowType === 'subprojectHeader' &&
                      row?.parentGroupId === projectGroupId &&
                      row?.groupId
                    ) {
                      groupIdsToRemove.add(row.groupId);
                    }
                  });
                  const isArchived = (row) => {
                    const rowType = row?._rowType || '';
                    return rowType.toLowerCase().startsWith('archive') || !!row?.archiveWeekLabel;
                  };
                  const filteredRows = taskRows.filter((row) => {
                    if (isArchived(row)) return true;
                    if (row?._rowType === 'projectHeader' && row.projectNickname === projectKey) return false;
                    if (row?.parentGroupId && groupIdsToRemove.has(row.parentGroupId)) return false;
                    if (row?.projectNickname === projectKey) return false;
                    return true;
                  });
                  if (filteredRows.length !== taskRows.length) {
                    await saveTaskRows(filteredRows, DEFAULT_PROJECT_ID, currentYear);
                  }
                } catch (err) {
                  console.error('Failed to clean up task rows on remove from plan', err);
                }
              })();
            }
            // Chip cleanup is now async (Supabase). The command pattern's
            // execute is synchronous and not awaited, so wrap the chip
            // section in an async IIFE. capturedChipState is set inside the
            // IIFE so undo() restores the pre-archive state — the slight
            // delay before capture is acceptable because the command can't
            // be undone until executeCommand returns and the user takes a
            // distinct action.
            (async () => {
              try {
                const chipState = await loadTacticsChipsState(currentYear);
                if (capturedChipState === null) {
                  capturedChipState = chipState;
                }
                const projectChips = Array.isArray(chipState.projectChips) ? chipState.projectChips : [];
                const filteredChips = projectChips.filter((chip) => chip.projectId !== itemId);
                if (filteredChips.length !== projectChips.length) {
                  const remainingIds = new Set(filteredChips.map((chip) => chip.id));
                  const overrides = chipState.chipTimeOverrides && typeof chipState.chipTimeOverrides === 'object'
                    ? chipState.chipTimeOverrides
                    : null;
                  const filteredOverrides = overrides
                    ? Object.fromEntries(Object.entries(overrides).filter(([chipId]) => remainingIds.has(chipId)))
                    : overrides;
                  await saveTacticsChipsState(
                    {
                      projectChips: filteredChips,
                      customProjects: chipState.customProjects,
                      chipTimeOverrides: filteredOverrides,
                    },
                    currentYear
                  );
                }
              } catch (err) {
                console.error('Failed to clean up chips on remove from plan', err);
              }
            })();
          }
        },
        undo: () => {
          if (capturedState) setState(capturedState);
          if (capturedChipState) {
            // Fire-and-forget restore; matches the async pattern in execute.
            saveTacticsChipsState(capturedChipState, currentYear).catch((err) => {
              console.error('Failed to restore chips on undo', err);
            });
          }
          if (capturedTaskRows) {
            // Fire-and-forget restore; matches the async pattern in execute.
            saveTaskRows(capturedTaskRows, DEFAULT_PROJECT_ID, currentYear).catch((err) => {
              console.error('Failed to restore task rows on undo', err);
            });
          }
        },
      };
      executeCommand(command);
    },
    [setState, executeCommand, currentYear, shortlist]
  );

  // ── Per-row inline button handlers (TableRow action buttons) ──────────────

  // Shared: index after the last prompt/response row of the clicked row's
  // section (keeps the blank 'data' separator row at the section bottom)
  const findSectionEndInsertIdx = (entries, fromRowIdx) => {
    let headerIdx = -1;
    for (let i = fromRowIdx; i >= 0; i--) {
      if (entries[i]?.__rowType === 'header') { headerIdx = i; break; }
    }
    if (headerIdx === -1) return -1;
    let insertAt = headerIdx + 1;
    for (let i = headerIdx + 1; i < entries.length; i++) {
      const t = entries[i]?.__rowType;
      if (t === 'header') break;
      if (t === 'prompt' || t === 'response') insertAt = i + 1;
    }
    return insertAt;
  };

  // Add a row of the same type. In paired sections (Outcomes, Actions) the
  // new row is appended at the bottom of the section — same as the pair
  // button. Elsewhere it inserts directly below the clicked row.
  const handleAddRowBelow = useCallback(
    (itemId, rowIdx, rowType, sectionType) => {
      const isPairedSection = sectionType === 'Outcomes' || sectionType === 'Actions';
      if (!isPairedSection) {
        insertRowType(itemId, rowIdx, sectionType, rowType);
        return;
      }
      let capturedState = null;
      const command = {
        execute: () => {
          setState((prev) => {
            if (capturedState === null) capturedState = cloneStagingState(prev);
            return {
              ...prev,
              shortlist: prev.shortlist.map((item) => {
                if (item.id !== itemId) return item;
                const entries = item.planTableEntries.map(cloneRowWithMetadata);
                const insertAt = findSectionEndInsertIdx(entries, rowIdx);
                if (insertAt === -1) return item;
                const newRow = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                defineRowMetadata(newRow, { rowType });
                entries.splice(insertAt, 0, newRow);
                return { ...item, planTableEntries: entries };
              }),
            };
          });
        },
        undo: () => { if (capturedState) setState(capturedState); },
      };
      executeCommand(command);
    },
    [insertRowType, setState, executeCommand]
  );

  // Add a prompt + response pair at the END of the clicked row's section
  // (e.g. add-pair on any Outcomes row appends an outcome + action pair
  // beneath the section's last row, not below the clicked row).
  const handleAddPairBelow = useCallback(
    (itemId, rowIdx) => {
      let capturedState = null;
      const command = {
        execute: () => {
          setState((prev) => {
            if (capturedState === null) capturedState = cloneStagingState(prev);
            return {
              ...prev,
              shortlist: prev.shortlist.map((item) => {
                if (item.id !== itemId) return item;
                const entries = item.planTableEntries.map(cloneRowWithMetadata);

                const insertAt = findSectionEndInsertIdx(entries, rowIdx);
                if (insertAt === -1) return item;

                const promptRow = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                defineRowMetadata(promptRow, { rowType: 'prompt' });
                const responseRow = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                defineRowMetadata(responseRow, { rowType: 'response' });
                entries.splice(insertAt, 0, promptRow, responseRow);
                return { ...item, planTableEntries: entries };
              }),
            };
          });
        },
        undo: () => { if (capturedState) setState(capturedState); },
      };
      executeCommand(command);
    },
    [setState, executeCommand]
  );

  // Send an Outcomes row to the Actions section: appends a Measurable
  // Outcome prompt (pre-filled with the outcome text) + an empty response
  // row at the end of the Actions section.
  const handleSendToActions = useCallback(
    (itemId, rowIdx) => {
      let capturedState = null;
      const command = {
        execute: () => {
          setState((prev) => {
            if (capturedState === null) capturedState = cloneStagingState(prev);
            return {
              ...prev,
              shortlist: prev.shortlist.map((item) => {
                if (item.id !== itemId) return item;
                const entries = item.planTableEntries.map(cloneRowWithMetadata);
                const source = entries[rowIdx];
                if (!source) return item;
                // Outcome text: prompt rows keep it at col 1, responses at col 2
                const text = ((source.__rowType === 'prompt' ? source[1] : source[2]) ?? '').trim();

                // Find the Actions section's last prompt/response row — NOT
                // the blank 'data' row that visually separates sections
                let inActions = false;
                let insertAt = -1;
                for (let i = 0; i < entries.length; i++) {
                  const t = entries[i]?.__rowType;
                  if (t === 'header') {
                    if (inActions) break;
                    inActions = entries[i].__sectionType === 'Actions';
                    if (inActions) insertAt = i + 1;
                  } else if (inActions && (t === 'prompt' || t === 'response')) {
                    insertAt = i + 1;
                  }
                }
                if (insertAt === -1) return item; // no Actions section

                const promptRow = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                promptRow[1] = text;
                defineRowMetadata(promptRow, { rowType: 'prompt' });
                const responseRow = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                defineRowMetadata(responseRow, { rowType: 'response' });
                entries.splice(insertAt, 0, promptRow, responseRow);
                return { ...item, planTableEntries: entries };
              }),
            };
          });
        },
        undo: () => { if (capturedState) setState(capturedState); },
      };
      executeCommand(command);
    },
    [setState, executeCommand]
  );

  // Handle click on drag handle to select row
  const handleHandleClick = useCallback(
    (e, itemId, rowIdx) => {
      e.stopPropagation();
      const addToSelection = e.metaKey || e.ctrlKey || e.shiftKey;
      selectRow(itemId, rowIdx, PLAN_TABLE_COLS, addToSelection);
    },
    [selectRow]
  );

  // Clear row selection when focusing into a cell input
  const handleInputFocus = useCallback(() => {
    if (selectedRows.size > 0) {
      clearSelection();
    }
  }, [selectedRows, clearSelection]);

  // Inline-edit a single project metadata field (name or tagline)
  const handleInlineProjectUpdate = useCallback(
    (itemId, field, newValue) => {
      let capturedState = null;
      const command = {
        execute: () => {
          setState((prev) => {
            if (capturedState === null) capturedState = cloneStagingState(prev);
            return {
              ...prev,
              shortlist: prev.shortlist.map((item) =>
                item.id === itemId ? { ...item, [field]: newValue } : item
              ),
            };
          });
        },
        undo: () => {
          if (capturedState) setState(capturedState);
        },
      };
      executeCommand(command);
    },
    [setState, executeCommand]
  );

  // GoalPanel action handler — goal-level mutations
  useEffect(() => {
    const handler = (e) => {
      const { action, goalId, color, nickname, name, index, rowIdx } = e.detail ?? {};

      if (action === 'deleteRow' && goalId != null && rowIdx != null) {
        deleteRows(selectedRows, goalId, rowIdx);
        clearSelection(); // reverts panel to the Goal section
      }

      if (action === 'toggleTotals' && goalId != null) {
        toggleItemOutcomeTotals(goalId);
      }

      if (action === 'toggleActionTimes' && goalId != null) {
        toggleItemActionTimes(goalId);
      }

      if (action === 'setColor' && goalId && color) {
        handleInlineProjectUpdate(goalId, 'color', color);
        const item = shortlist.find((i) => i.id === goalId);
        if (item) fireGoalSelection({ ...item, color });
      }

      if (action === 'setNickname' && goalId && nickname !== undefined) {
        handleInlineProjectUpdate(goalId, 'projectNickname', nickname);
        const item = shortlist.find((i) => i.id === goalId);
        if (item) fireGoalSelection({ ...item, projectNickname: nickname });
      }

      if (action === 'deleteGoal' && goalId) {
        const item = shortlist.find((i) => i.id === goalId);
        if (!item) return;
        // If the goal is on the plan, run the same cleanup as removing it
        // (Plan chips + System task rows) before deleting the project itself.
        if (item.addedToPlan) {
          handleTogglePlanStatus(goalId, false, false);
        }
        handleRemove(goalId);
        fireGoalSelection(null);
      }

      if (action === 'archiveGoal' && goalId) {
        // Same path as the goal table's archive button — moves the goal to
        // archived and cleans up its Plan chips. Selection is cleared since
        // the goal no longer exists on the page.
        handleArchiveAndCleanup(goalId, 'archived');
        fireGoalSelection(null);
      }

      if (action === 'completeGoal' && goalId) {
        handleArchiveAndCleanup(goalId, 'completed');
        fireGoalSelection(null);
      }

      if ((action === 'addToPlan' || action === 'removeFromPlan') && goalId) {
        const item = shortlist.find((i) => i.id === goalId);
        if (!item) return;
        const adding = action === 'addToPlan';
        handleTogglePlanStatus(goalId, adding);
        fireGoalSelection({ ...item, addedToPlan: adding });
      }

      // Shared helper: extract real (non-blank, non-placeholder) subproject rows
      // Returns { names: string[], entryIndices: number[] } — both arrays are
      // index-aligned so names[i] always corresponds to entryIndices[i].
      const extractRealSubprojects = (entries) => {
        let inSubs = false;
        const names = [];
        const entryIndices = [];
        for (let i = 0; i < entries.length; i++) {
          const row = entries[i];
          if (row?.__rowType === 'header') {
            inSubs = row.__sectionType === 'Subprojects';
          } else if (inSubs && row?.__rowType === 'prompt') {
            // Prompt rows: name at col 1 (matches useProjectsData format)
            const n = (row[COL.LABEL] ?? '').trim();
            if (n && n !== 'Subproject') {
              names.push(n);
              entryIndices.push(i);
            }
          }
        }
        return { names, entryIndices };
      };

      if (action === 'addSubproject' && goalId && name) {
        const item = shortlist.find((i) => i.id === goalId);
        if (!item) return;
        const { names: currentSubs } = extractRealSubprojects(item.planTableEntries || []);
        const newSubs = [...currentSubs, name];

        let capturedState = null;
        const command = {
          execute: () => {
            setState((prev) => {
              if (capturedState === null) capturedState = cloneStagingState(prev);
              return {
                ...prev,
                shortlist: prev.shortlist.map((it) => {
                  if (it.id !== goalId) return it;
                  const entries = it.planTableEntries.map(cloneRowWithMetadata);
                  // Insert after the last real subproject row, or after the prompt row
                  // if there are none yet. `insertAt` tracks the position after every
                  // non-prompt, non-header Subprojects row (including blank placeholders)
                  // so the new row always lands at the end of the section.
                  let inSubs = false;
                  let insertAt = entries.length;
                  for (let i = 0; i < entries.length; i++) {
                    const row = entries[i];
                    if (row?.__rowType === 'header') {
                      inSubs = row.__sectionType === 'Subprojects';
                    } else if (inSubs) {
                      // Advance past every row in the section (blank placeholders,
                      // section prompt, and added prompt rows) so new entries
                      // always land at the end in the order they were added.
                      insertAt = i + 1;
                    }
                  }
                  const newRow = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                  newRow[COL.LABEL] = name;
                  defineRowMetadata(newRow, { rowType: 'prompt', sectionType: 'Subprojects' });
                  entries.splice(insertAt, 0, newRow);
                  return {
                    ...it,
                    planTableEntries: entries,
                    planSubprojectRowCount: (it.planSubprojectRowCount ?? 1) + 1,
                  };
                }),
              };
            });
            fireGoalSelection(item, newSubs);
          },
          undo: () => { if (capturedState) setState(capturedState); },
        };
        executeCommand(command);
      }

      if (action === 'reorderSubprojects' && goalId) {
        const { fromIndex, toIndex } = e.detail ?? {};
        if (fromIndex === undefined || toIndex === undefined) return;
        const item = shortlist.find((i) => i.id === goalId);
        if (!item) return;
        const { names: currentSubs, entryIndices } = extractRealSubprojects(item.planTableEntries || []);

        // toIndex may equal currentSubs.length (drop at end) — that's valid
        if (fromIndex < 0 || fromIndex >= currentSubs.length || toIndex < 0 || toIndex > currentSubs.length) return;

        const insertAt = fromIndex < toIndex ? toIndex - 1 : toIndex;
        if (insertAt === fromIndex) return;

        const newSubs = [...currentSubs];
        const [moved] = newSubs.splice(fromIndex, 1);
        newSubs.splice(insertAt, 0, moved);

        let capturedState = null;
        const command = {
          execute: () => {
            setState((prev) => {
              if (capturedState === null) capturedState = cloneStagingState(prev);
              return {
                ...prev,
                shortlist: prev.shortlist.map((it) => {
                  if (it.id !== goalId) return it;
                  const entries = it.planTableEntries.map(cloneRowWithMetadata);
                  const fromEntryIdx = entryIndices[fromIndex];
                  // End-drop: insert just after the last real subproject row,
                  // NOT at entries.length (that lands past the Subprojects
                  // section and creates a phantom row in the next section).
                  const toEntryIdx = entryIndices[toIndex] ?? (entryIndices[entryIndices.length - 1] + 1);
                  if (fromEntryIdx === undefined) return it;
                  const [movedRow] = entries.splice(fromEntryIdx, 1);
                  const adjustedEntry = fromIndex < toIndex ? toEntryIdx - 1 : toEntryIdx;
                  entries.splice(adjustedEntry, 0, movedRow);
                  return { ...it, planTableEntries: entries };
                }),
              };
            });
            fireGoalSelection(item, newSubs);
          },
          undo: () => { if (capturedState) setState(capturedState); },
        };
        executeCommand(command);
      }

      if (action === 'removeSubproject' && goalId && index !== undefined) {
        const item = shortlist.find((i) => i.id === goalId);
        if (!item) return;
        // Use only real rows so chip index === entry index — blank placeholders excluded
        const { names: currentSubs, entryIndices } = extractRealSubprojects(item.planTableEntries || []);
        const newSubs = currentSubs.filter((_, i) => i !== index);
        const targetEntryIdx = entryIndices[index];
        if (targetEntryIdx === undefined) return;

        let capturedState = null;
        const command = {
          execute: () => {
            setState((prev) => {
              if (capturedState === null) capturedState = cloneStagingState(prev);
              return {
                ...prev,
                shortlist: prev.shortlist.map((it) => {
                  if (it.id !== goalId) return it;
                  const entries = it.planTableEntries.map(cloneRowWithMetadata);
                  const count = it.planSubprojectRowCount ?? 1;
                  if (count <= 1) {
                    // Clear rather than remove to keep section structure intact
                    entries[targetEntryIdx] = Array.from({ length: PLAN_TABLE_COLS }, () => '');
                    defineRowMetadata(entries[targetEntryIdx], { rowType: 'response', sectionType: 'Subprojects' });
                    return { ...it, planTableEntries: entries };
                  }
                  entries.splice(targetEntryIdx, 1);
                  return { ...it, planTableEntries: entries, planSubprojectRowCount: count - 1 };
                }),
              };
            });
            fireGoalSelection(item, newSubs);
          },
          undo: () => { if (capturedState) setState(capturedState); },
        };
        executeCommand(command);
      }
    };
    window.addEventListener(GOAL_PANEL_ACTION_EVENT, handler);
    return () => window.removeEventListener(GOAL_PANEL_ACTION_EVENT, handler);
  }, [handleInlineProjectUpdate, handleTogglePlanStatus, handleArchiveAndCleanup, handleRemove, deleteRows, selectedRows, clearSelection, toggleItemOutcomeTotals, toggleItemActionTimes, shortlist, fireGoalSelection, setState, executeCommand]);

  // Wait for auth to complete before rendering content that depends on user-scoped data
  if (isAuthLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-center">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" style={{ animation:'spin 1s linear infinite', margin:'0 auto 16px' }}>
            <circle cx="12" cy="12" r="10" stroke="rgba(43,89,182,0.15)" strokeWidth="2.5"/>
            <path d="M22 12a10 10 0 0 0-10-10" stroke="var(--brand-deep)" strokeWidth="2.5" strokeLinecap="round"/>
          </svg>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Render the simple table (unified row rendering)
  // Shared width floor so the prompt box and the white table card stop
  // shrinking exactly where the table does. The table's intrinsic floor (its
  // fixed columns + padding) is measured at runtime rather than hard-coded:
  // when the card's content overflows (scrollWidth > clientWidth) the table
  // has hit its floor, and that overflow width becomes the min-width for both
  // boxes. ResizeObserver re-checks on every card resize (i.e. window resize).
  const tableCardRef = useRef(null);

  // Space covered by an open side panel (Goal / Gear) on the right edge of
  // the viewport. Instead of a hardcoded 320px reservation, the goal table
  // and prompt box shrink to exactly the panel's current width (tracking
  // live resize drags too) and reclaim the full page width when no panel is
  // open. `panelGap` is the visual gutter kept between content and the
  // panel's left edge (or the page edge when closed).
  const { inset: panelInset, isResizing: panelResizing } = usePanelInset();
  const panelGap = 16;
  const contentRightReserve = panelInset + panelGap;
  const contentMaxWidthTransition = panelResizing
    ? 'none'
    : 'max-width 0.25s cubic-bezier(0.4,0,0.2,1)';
  const [boxMinWidth, setBoxMinWidth] = useState(null);
  useLayoutEffect(() => {
    const el = tableCardRef.current;
    if (!el) return undefined;
    const measure = () => {
      if (el.scrollWidth > el.clientWidth) {
        // scrollWidth = overflowing content width; add back the card's right
        // padding (p-4, 16px) the overflow swallows, plus 1px border per side.
        setBoxMinWidth(el.scrollWidth + 18);
      }
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [shortlist.length]);

  const renderTable = (item) => {
    const entries = item.planTableEntries || [];

    // Calculate outcome totals for this item
    const outcomeTotals = calculateOutcomeTotals(entries);
    const outcomeSectionTotal = calculateOutcomeSectionTotal(entries, outcomeTotals);

    return (
      <div style={{ border: '1.5px solid #1A1A1A', borderTop: 'none', borderRadius: '0 0 8px 8px', background: '#fff', overflow: 'hidden' }}>
        <table
          className="w-full border-collapse text-left"
          style={{ fontSize: `${Math.round(14 * textSizeScale)}px`, tableLayout: 'fixed' }}
        >
          <colgroup>
            <col style={{ width: 'calc(36px * var(--pz))' }} />   {/* col 0: gutter / section number */}
            <col style={{ width: 'calc(92px * var(--pz))' }} />   {/* col 1: prompt button cell */}
            <col style={{ width: 'calc(31px * var(--pz))' }} />   {/* col 2: response button extension — col1+col2=123px */}
            <col />                          {/* col 3: flex content */}
            <col />                          {/* col 4: flex content */}
            <col style={{ width: 'calc(140px * var(--pz))' }} />  {/* col 5: estimate */}
            <col style={{ width: 'calc(120px * var(--pz))' }} />  {/* col 6: time value */}
          </colgroup>
          <tbody>
            {entries.map((rowValues, rowIdx) => {
              const rowType = rowValues.__rowType || 'data';
              const sectionType = getSectionTypeForRow(entries, rowIdx);

              // Subprojects are managed via the side panel — skip table rendering
              if (sectionType === 'Subprojects') return null;

              // First row of this type in its section cannot be deleted
              let sectionStart = rowIdx;
              for (let i = rowIdx - 1; i >= 0; i--) {
                if (entries[i]?.__rowType === 'header') { sectionStart = i + 1; break; }
                if (i === 0) sectionStart = 0;
              }
              const isFirstOfType = !entries.slice(sectionStart, rowIdx).some(e => e?.__rowType === rowType);

              return (
                <TableRow
                  key={`${item.id}-row-${rowIdx}`}
                  item={item}
                  rowValues={rowValues}
                  rowIdx={rowIdx}
                  rowType={rowType}
                  sectionType={sectionType}
                  isFirstOfType={isFirstOfType}
                  isCellSelected={isCellSelected}
                  isRowSelected={isRowSelected(item.id, rowIdx)}
                  isDropTarget={isDropTarget(item.id, rowIdx)}
                  isDragged={isRowDragged(item.id, rowIdx)}
                  onCellChange={handlePlanTableCellChange}
                  onEstimateChange={handlePlanEstimateChange}
                  onCellMouseDown={handleCellMouseDown}
                  onCellMouseEnter={handleCellMouseEnter}
                  onHandleClick={handleHandleClick}
                  onInputFocus={handleInputFocus}
                  onEnterKeyAddRow={addRowOnEnter}

                  onAddRowBelow={handleAddRowBelow}
                  onAddPairBelow={handleAddPairBelow}
                  onSendToActions={handleSendToActions}
                  onDragStart={handleDragStart}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  onDragEnd={handleDragEnd}
                  textSizeScale={textSizeScale}
                  selectedCells={selectedCells}
                  selectedRows={selectedRows}
                  outcomeTotals={outcomeTotals}
                  outcomeSectionTotal={outcomeSectionTotal}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  const PAGE_BG = {
    backgroundColor: '#ffffff',
    backgroundImage: [
      'radial-gradient(ellipse 80% 60% at 105% -10%, rgba(130,155,210,0.45) 0%, transparent 62%)',
      'radial-gradient(ellipse 60% 45% at -5% 110%, rgba(130,155,210,0.28) 0%, transparent 58%)',
      'radial-gradient(ellipse 160% 65% at 95% 112%, rgba(130,155,210,0.38) 0%, transparent 60%)',
      'radial-gradient(ellipse 140% 55% at 45% 112%, rgba(130,155,210,0.25) 0%, transparent 58%)',
      // Grid lines as an SVG tile rather than 1px gradient hard-stops:
      // gradient hairlines round to zero device pixels and vanish when the
      // effective DPR drops below 1 (browser zoom < 100% on a 1x monitor).
      // The SVG stroke antialiases instead, so the grid survives any zoom.
      'url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2732%27 height=%2732%27%3E%3Cpath d=%27M0 0.5 H32 M0.5 0 V32%27 stroke=%27rgba(130,155,210,0.15)%27 stroke-width=%271%27/%3E%3C/svg%3E")',
    ].join(','),
    backgroundSize: '100% 100%, 100% 100%, 100% 100%, 100% 100%, 32px 32px',
    backgroundPosition: '0 0, 0 0, 0 0, 0 0, -1px -1px',
    backgroundAttachment: 'fixed',
  };

  return (
    <>
      <div className="h-screen overflow-y-auto text-slate-800" style={{...PAGE_BG}}>
        <div
          className="sticky top-0 z-20 px-4 pt-4 pb-4" style={{...PAGE_BG}}
        >
          <NavigationBar
            onRevertArchive={!draftYear && allYears.some(y => y.status === 'archived') ? handleRevertArchive : null}
          />
          <div
            style={{
              // Right edge stays aligned with the table card below: same
              // panel reserve, plus this box's own 36px marginLeft.
              maxWidth: `calc(100% - ${contentRightReserve + 36}px)`,
              transition: contentMaxWidthTransition,
              minWidth: boxMinWidth ? boxMinWidth - 36 : undefined,
              marginLeft: 36,
              background: '#fff',
              border: '1.5px solid #1A1A1A',
              borderRadius: 10,
              padding: '0 16px',
              height: 50,
              marginTop: 8,
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              boxShadow: '0 1px 2px rgba(0,0,0,0.06)',
              boxSizing: 'border-box',
            }}
          >
            <input
              id="staging-input"
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAdd();
                }
              }}
              style={{
                flex: 1,
                border: 'none',
                outline: 'none',
                background: 'transparent',
                fontSize: `${Math.round(14 * textSizeScale)}px`,
                fontFamily: 'var(--font-sans)',
                color: '#1F1F1F',
              }}
              placeholder="What would you like to get done?"
            />
            <span style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 'calc(10px * var(--pz))',
              letterSpacing: '.08em',
              textTransform: 'uppercase',
              color: '#9E9E9E',
              whiteSpace: 'nowrap',
              flexShrink: 0,
            }}>
              ↵ to create
            </span>
          </div>
        </div>

        <div className="px-4 pb-4" style={{ isolation: 'isolate' }}>
          <div
            ref={tableCardRef}
            style={{
              // Shrink to make room for the open panel at its current width;
              // full page width (minus the gutter) when no panel is open.
              maxWidth: `calc(100% - ${contentRightReserve}px)`,
              transition: contentMaxWidthTransition,
              minWidth: boxMinWidth ?? undefined,
              display: 'flex',
              flexDirection: 'column',
              gap: 8,
            }}
          >
              {shortlist.map((item) => {
                const planEntries = clonePlanTableEntries(item.planTableEntries);
                const { projectTotal } = calculateTimeTotals(planEntries);

                const headerBackground = item.color || '#f3f4f6';
                const headerTextColor = item.color ? getContrastTextColor(item.color) : '#0f172a';

                return (
                  <div key={item.id}>
                    <div className="flex items-start gap-2">
                      <div className="mt-1 flex items-center justify-center" style={{ height: 'calc(28px * var(--pz))', width: 'calc(28px * var(--pz))' }}>
                        {item.planTableVisible ? (
                          <button
                            type="button"
                            className="inline-flex items-center justify-center rounded-full border border-transparent text-slate-700 hover:text-slate-900"
                            style={{ height: 'calc(28px * var(--pz))', width: 'calc(28px * var(--pz))' }}
                            onClick={() => togglePlanTable(item.id)}
                            aria-label={
                              item.planTableCollapsed ? 'Expand plan table' : 'Collapse plan table'
                            }
                          >
                            <SquarePlus
                              size={Math.round(18 * textSizeScale)}
                              className={`transition-transform ${
                                item.planTableCollapsed ? '' : 'rotate-45'
                              }`}
                            />
                          </button>
                        ) : null}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div
                          style={{
                            position: 'relative',
                            display: 'grid',
                            backgroundColor: headerBackground,
                            color: headerTextColor,
                            border: '1.5px solid #1A1A1A',
                            borderRadius: (item.planTableVisible && !item.planTableCollapsed) ? '8px 8px 0 0' : '8px',
                            // All fixed dimensions scale with the page zoom.
                            // fontSize here also sizes the project name and
                            // tagline (InlineEditableText inherits font).
                            fontSize: 'calc(16px * var(--pz))',
                            height: 'calc(40px * var(--pz))',
                            paddingLeft: 'calc(12px * var(--pz))',
                            paddingRight: 'calc(12px * var(--pz))',
                            fontWeight: 600,
                            gridTemplateColumns: '1fr auto calc(140px * var(--pz)) calc(24px * var(--pz)) calc(80px * var(--pz))',
                            alignItems: 'center',
                            gap: 'calc(12px * var(--pz))',
                            cursor: 'pointer',
                            outline: selectedGoalId === item.id ? '2px solid rgba(0,0,0,0.25)' : 'none',
                            outlineOffset: '-2px',
                            boxSizing: 'border-box',
                          }}
                          onClick={() => {
                            setSelectedGoalId(item.id);
                            // Clear any row/cell selection so the panel shows
                            // the Goal section instead of the Row section
                            clearSelection();
                            fireGoalSelection(item);
                          }}
                        >
                          <div className="w-full flex items-center gap-2 font-semibold min-w-0 overflow-hidden" style={{ maskImage: 'linear-gradient(to right, black 97%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to right, black 97%, transparent 100%)' }}>
                            <span className="flex items-baseline gap-0 min-w-0">
                              <InlineEditableText
                                value={item.projectName || item.text}
                                onSave={(v) => handleInlineProjectUpdate(item.id, 'projectName', v)}
                                placeholder="Project name"
                                style={{ fontWeight: 600, flexShrink: 0 }}
                              />
                              <span className="mx-1.5 opacity-50 shrink-0 select-none" style={{ fontWeight: 400 }}>·</span>
                              <InlineEditableText
                                value={item.projectTagline ?? ''}
                                onSave={(v) => handleInlineProjectUpdate(item.id, 'projectTagline', v)}
                                placeholder="Add tagline"
                                className="truncate"
                                style={{ fontWeight: 400, opacity: item.projectTagline ? 0.85 : 0.5, minWidth: 0 }}
                              />
                            </span>
                          </div>
                          <div></div>
                          <div style={{ width: 'calc(140px * var(--pz))', minWidth: 'calc(140px * var(--pz))' }}></div>
                          <div
                            style={{ width: 'calc(24px * var(--pz))', minWidth: 'calc(24px * var(--pz))' }}
                            className="flex items-center justify-end"
                          >
                            {item.addedToPlan && (
                              <span style={{
                                fontFamily: 'var(--font-mono)',
                                fontSize: 'calc(9px * var(--pz))',
                                color: '#1A1A1A',
                                background: 'rgba(255,255,255,0.88)',
                                borderRadius: 999,
                                padding: 'calc(2px * var(--pz)) calc(8px * var(--pz))',
                                textTransform: 'uppercase',
                                letterSpacing: '.05em',
                                flexShrink: 0,
                                whiteSpace: 'nowrap',
                              }}>On Plan</span>
                            )}
                          </div>
                          <div
                            className="text-right font-semibold"
                            // Right inset matched to the table's time column:
                            // container border (1) + p-3 (12) + cell border (1)
                            // + cell paddingRight (10) = 24px; header card is
                            // border (1) + pr-3 (12) + 11px = 24px
                            style={{ fontSize: `${Math.round(14 * textSizeScale)}px`, paddingRight: 'calc(11px * var(--pz))' }}
                          >
                            {projectTotal}
                          </div>
                        </div>
                        {item.planTableVisible && !item.planTableCollapsed
                          ? renderTable(item)
                          : null}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      <ArchiveYearModal
        isOpen={isArchiveModalOpen}
        onClose={() => setIsArchiveModalOpen(false)}
        yearNumber={activeYear?.yearNumber}
      />
    </>
  );
}

